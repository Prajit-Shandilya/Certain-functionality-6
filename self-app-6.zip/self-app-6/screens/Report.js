import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class Report extends React.Component{
  render(){
    return(
      <View>
      <Text>This is Report screen </Text>
      </View>
    )
  }
}