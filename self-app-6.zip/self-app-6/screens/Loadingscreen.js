import React, { Component } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import firebase from 'firebase';

export default class Loadingscreen extends Component {
  checkLogin = () => {
    firebase.auth().onAuthStateChanged((users) => {
      if (users) {
        this.props.navigation.navigate('Main');
      } else {
        this.props.navigation.navigate('Loginscreen');
      }
    });
  };
  componentDidMount() {
    this.checkLogin();
  }

  render() {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    );
  }
}
