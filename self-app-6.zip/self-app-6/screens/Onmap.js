import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Dimensions,
  TextInput,
  SafeAreaView,
  Platform,
  StatusBar,
} from 'react-native';
import MapView from 'react-native-maps';

export default class Onmap extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      latitude: 90.0,
      longitude: 5.0,
    };
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
        <SafeAreaView style={styles.droidSafeArea} />
        <View style={{ flex: 0.2 }}>
          <TextInput
            style={styles.inputStyle}
            placeholder="Enter your longitude"
            placeholderTextColor="white"
            onChangeText={(text) => {
              this.setState({
                longitude: text,
              });
            }}
          />
          <TextInput
            style={styles.inputStyle}
            placeholder="Enter your latitude"
            placeholderTextColor="white"
            onChangeText={(text) => {
              this.setState({
                latitude: text,
              });
            }}
          />
        </View>
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            region={{
              latitude: this.state.latitude,
              longitude: this.state.longitude,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421,
            }}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  inputStyle: {
    height: 40,
    backgroundColor: 'black',
    borderWidth: 1,
    borderRadius: 20,
    marginTop: 20,
    marginRight: 20,
    marginLeft: 20,
    textAlign: 'center',
    alignSelf: 'center',

    width: 200,
  },
  mapContainer: {
    flex: 0.7,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  droidSafeArea: {
    marginTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
});
