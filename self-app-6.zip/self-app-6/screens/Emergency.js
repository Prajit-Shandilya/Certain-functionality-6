import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import RNImmediatePhoneCall from 'react-native-immediate-phone-call';

export default class Emergency extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.titleText}>Emergency Services</Text>
        <View style={styles.sosBtnContainer}>
          <TouchableOpacity
            style={{ alignSelf: 'center', marginTop: '10%' }}
            onPress={() => {
              RNImmediatePhoneCall.immediatePhoneCall('100');
            }}>
            <Image
              source={require('../assets/sos.jpg')}
              style={styles.sosBtn}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.helpBtn1}  onPress={() => {
              RNImmediatePhoneCall.immediatePhoneCall('1091');
            }}>
            <Image
              source={require('../assets/support.png')}
              style={styles.buttonLogo1}
            />
            <Text
              style={{
                fontSize: '15px',
                fontWeight: 'bold',
                textAlign: 'center',
              }}>
              Women Helpline
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.helpBtn1} onPress={() => {
              RNImmediatePhoneCall.immediatePhoneCall('1098');
            }}>
            <Image
              source={require('../assets/baby-boy.png')}
              style={styles.buttonLogo2}
            />
            <Text
              style={{
                fontSize: '15px',
                fontWeight: 'bold',
                textAlign: 'center',
              }}>
              Child Helpline
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.helpBtn1} onPress={() => {
              RNImmediatePhoneCall.immediatePhoneCall('102');
            }}>
            <Image
              source={require('../assets/ambulance.png')}
              style={styles.buttonLogo2}
            />
            <Text
              style={{
                fontSize: '15px',
                fontWeight: 'bold',
                textAlign: 'center',
              }}>
              Ambulance Services
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.helpBtn1} onPress={() => {
              RNImmediatePhoneCall.immediatePhoneCall('101');
            }}>
            <Image
              source={require('../assets/fire.png')}
              style={styles.buttonLogo1}
            />
            <Text
              style={{
                fontSize: '15px',
                fontWeight: 'bold',
                textAlign: 'center',
              }}>
              Fire Brigade
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  sosBtn: {
    borderRadius: 280,
    width: 150,
    height: 150,
  },
  titleText: {
    alignSelf: 'center',
    marginTop: '3%',
    fontSize: '34px',
    backgroundColor: 'crimson',
    color: 'white',
    fontWeight: 'bold',
  },
  buttonContainer: {
    flex: 1,

    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  helpBtn1: {
    width: 150,
    height: 120,
    backgroundColor: 'white',
    borderWidth: 0.01,
    borderRadius: 6,
    borderColor: 'gray',
    marginTop: '4%',
    justifyContent: 'center',
  },
  buttonLogo1: {
    width: 60,
    height: 80,
    alignSelf: 'center',
  },
  buttonLogo2: {
    width: 80,
    height: 80,
    alignSelf: 'center',
  },
});
